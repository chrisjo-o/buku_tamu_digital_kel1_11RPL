<?php
require 'koneksi.php';

// Ambil kata kunci pencarian dari URL jika ada
$keyword = $_GET['keyword'] ?? '';

$tamu = [];
try {
    // Jika ada kata kunci pencarian, gunakan klausa WHERE untuk memfilter data
    if (!empty($keyword)) {
        $query = "SELECT * FROM tamu WHERE nama LIKE ? OR instansi LIKE ? OR keperluan LIKE ? ORDER BY tanggal_kunjung DESC";
        $stmt = mysqli_prepare($koneksi, $query);
        $like_keyword = "%" . $keyword . "%";
        mysqli_stmt_bind_param($stmt, "sss", $like_keyword, $like_keyword, $like_keyword);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
    } else {
        // Jika tidak ada pencarian, ambil semua data seperti biasa
        $query = "SELECT * FROM tamu ORDER BY tanggal_kunjung DESC";
        $result = mysqli_query($koneksi, $query);
    }

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $tamu[] = $row;
        }
    }
} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buku Tamu Digital - PROJECT-11 RPL</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts: Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom External CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light" style="font-family: 'Poppins', sans-serif;">

    <div class="container py-5">
        <!-- Header Section -->
        <header class="text-center mb-5">
            <h1 class="fw-bold text-primary"><span class="text-dark">Buku</span> Tamu Digital</h1>
            <p class="text-muted">PROJECT-11 RPL | Sistem Informasi Berbasis Website</p>
        </header>

        <!-- Action Add Entry & Search Bar -->
        <div class="row mb-4 g-3 align-items-center">
            <div class="col-md-6">
                <a href="tambah/tambah.php" class="btn btn-primary px-4 py-2 shadow-sm fw-medium">
                    + Kirim Masukan Baru
                </a>
            </div>
            <!-- Form Pencarian -->
            <div class="col-md-6">
                <form action="" method="GET" class="d-flex gap-2">
                    <input type="text" name="keyword" class="form-control" placeholder="Cari nama, instansi, atau keperluan..." value="<?= htmlspecialchars($keyword) ?>">
                    <button type="submit" class="btn btn-outline-primary px-4 fw-medium">Cari</button>
                    <?php if (!empty($keyword)): ?>
                        <a href="index.php" class="btn btn-outline-secondary px-3">Reset</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <!-- Entries Section -->
        <section class="entries">
            <div class="d-flex align-items-center mb-3">
                <h3 class="fs-5 fw-bold text-dark mb-0 me-2">Data Kunjungan</h3>
                <span class="badge bg-primary rounded-pill px-3 py-2"><?= count($tamu) ?></span>
                <?php if (!empty($keyword)): ?>
                    <span class="ms-3 text-muted small">Hasil pencarian untuk: "<strong><?= htmlspecialchars($keyword) ?></strong>"</span>
                <?php endif; ?>
            </div>

            <?php if (empty($tamu)): ?>
                <div class="alert alert-white text-center py-5 bg-white shadow-sm rounded border-0">
                    <p class="text-muted mb-0">Tidak ada data tamu yang ditemukan.</p>
                </div>
            <?php else: ?>
                <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                    <?php foreach ($tamu as $t): 
                        $tanggal_indo = '-';
                        if (!empty($t['tanggal_kunjung']) && $t['tanggal_kunjung'] != '0000-00-00 00:00:00') {
                            $tanggal = date_create($t['tanggal_kunjung']);
                            $tanggal_indo = date_format($tanggal, 'd M Y, H:i');
                        }
                    ?>
                        <div class="col">
                            <div class="card h-100 border-0 shadow-sm rounded-4 p-3 bg-white">
                                <div class="card-body d-flex flex-column">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <h5 class="card-title fw-bold text-dark mb-0"><?= htmlspecialchars($t['nama']) ?></h5>
                                        <span class="badge bg-light text-secondary border small"><?= $tanggal_indo ?></span>
                                    </div>
                                    <h6 class="card-subtitle mb-3 text-primary fw-medium small"><?= htmlspecialchars($t['instansi']) ?></h6>
                                    
                                    <div class="card-text text-secondary small mb-4 flex-grow-1">
                                        <p class="mb-1"><strong>Email:</strong> <?= htmlspecialchars($t['email'] ?: '-') ?></p>
                                        <p class="mb-1"><strong>Telepon:</strong> <?= htmlspecialchars($t['telepon'] ?: '-') ?></p>
                                        <p class="mb-0 mt-2 p-2 bg-light rounded"><strong>Keperluan:</strong><br><?= nl2br(htmlspecialchars($t['keperluan'])) ?></p>
                                    </div>

                                    <div class="d-flex justify-content-end gap-2 pt-2 border-top">
                                        <a href="edit/edit.php?id=<?= $t['id'] ?>" class="btn btn-outline-warning btn-sm px-3 fw-medium">Edit</a>
                                        <a href="hapus/hapus.php?id=<?= $t['id'] ?>" class="btn btn-outline-danger btn-sm px-3 fw-medium" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>