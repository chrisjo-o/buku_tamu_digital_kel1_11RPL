<?php
require '../koneksi.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $instansi = trim($_POST['instansi'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telepon = trim($_POST['telepon'] ?? '');
    $keperluan = trim($_POST['keperluan'] ?? '');
    // Ambil input tanggal, jika kosong gunakan waktu sekarang (format SQL datetime: Y-m-d H:i:s)
    $tanggal_kunjung = !empty($_POST['tanggal_kunjung']) ? $_POST['tanggal_kunjung'] . ':00' : date('Y-m-d H:i:s');

    if (!empty($nama) && !empty($instansi) && !empty($email) && !empty($keperluan)) {
        $stmt = mysqli_prepare($koneksi, "INSERT INTO tamu (nama, instansi, email, telepon, keperluan, tanggal_kunjung) VALUES (?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssssss", $nama, $instansi, $email, $telepon, $keperluan, $tanggal_kunjung);
        
        if (mysqli_stmt_execute($stmt)) {
            header('Location: ../index.php?status=success');
            exit;
        } else {
            $error = "Gagal menyimpan data: " . mysqli_error($koneksi);
        }
        mysqli_stmt_close($stmt);
    } else {
        $error = "Semua field wajib harus diisi kecuali No. Telepon!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Masukan - Buku Tamu Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light" style="font-family: 'Poppins', sans-serif;">
    <div class="container py-5">
        <div class="row justify-content-center mb-4">
            <div class="col-md-8 d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 fw-bold text-primary mb-1">Tambah Tamu Baru</h1>
                    <p class="text-muted small mb-0">PROJECT-11 RPL | Silakan isi form di bawah ini.</p>
                </div>
                <a href="../index.php" class="btn btn-outline-secondary btn-sm px-3 shadow-sm">&larr; Kembali</a>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                    <div class="card-body">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?= htmlspecialchars($error) ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <form action="" method="POST">
                            <div class="mb-3">
                                <label for="nama" class="form-label fw-medium text-secondary">Nama Lengkap</label>
                                <input type="text" class="form-control" id="nama" name="nama" required placeholder="Masukkan nama Anda">
                            </div>
                            <div class="mb-3">
                                <label for="instansi" class="form-label fw-medium text-secondary">Asal Instansi</label>
                                <input type="text" class="form-control" id="instansi" name="instansi" required placeholder="Contoh: SMK Negeri 1 Cilegon">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label fw-medium text-secondary">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required placeholder="contoh@email.com">
                            </div>
                            <div class="mb-3">
                                <label for="telepon" class="form-label fw-medium text-secondary">No. Telepon / WhatsApp</label>
                                <input type="text" class="form-control" id="telepon" name="telepon" placeholder="Contoh: 081234567890">
                                <div class="form-text text-muted">Opsional (boleh dikosongkan).</div>
                            </div>
                            <div class="mb-3">
                                <label for="tanggal_kunjung" class="form-label fw-medium text-secondary">Tanggal & Waktu Kunjungan</label>
                                <input type="datetime-local" class="form-control" id="tanggal_kunjung" name="tanggal_kunjung" required value="<?= date('Y-m-d\TH:i') ?>">
                            </div>
                            <div class="mb-4">
                                <label for="keperluan" class="form-label fw-medium text-secondary">Tujuan Kunjungan / Keperluan</label>
                                <textarea class="form-control" id="keperluan" name="keperluan" rows="4" placeholder="Tuliskan tujuan kunjungan..." required></textarea>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary py-2 fw-medium shadow-sm">Kirim Masukan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>