<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "db_buku_tamu";

// Membuat koneksi menggunakan MySQLi
$koneksi = mysqli_connect($host, $user, $password, $database);

// Cek apakah koneksi berhasil
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>